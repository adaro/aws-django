**To delete a launch configuration**

This example deletes the specified launch configuration::

	aws autoscaling delete-launch-configuration --launch-configuration-name my-lc

For more information, see `Shut Down Your Auto Scaling Process`_ in the *Auto Scaling Developer Guide*.

.. _`Shut Down Your Auto Scaling Process`: http://docs.aws.amazon.com/AutoScaling/latest/DeveloperGuide/as-process-shutdown.html

